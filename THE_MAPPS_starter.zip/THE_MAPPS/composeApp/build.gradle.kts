plugins {
    alias(libs.plugins.kotlinMultiplatform)
    alias(libs.plugins.composeMultiplatform)
    alias(libs.plugins.composeCompiler)
}

kotlin {
    iosArm64 {
        binaries.framework {
            baseName = "THE_MAPPS"
            isStatic = true
            linkerOpts(
                "-lc++",
                "-lz",
                "-framework", "CoreFoundation",
                "-framework", "CoreGraphics",
                "-framework", "CoreText",
                "-framework", "Foundation",
                "-framework", "ImageIO",
                "-framework", "Metal",
                "-framework", "QuartzCore",
            )
        }
    }

    sourceSets {
        commonMain.dependencies {
            implementation(compose.runtime)
            implementation(compose.foundation)
            implementation(compose.material3)
            implementation(compose.ui)
            implementation("org.maplibre.compose:maplibre-compose:${libs.versions.maplibre.compose.get()}")
        }
    }
}
