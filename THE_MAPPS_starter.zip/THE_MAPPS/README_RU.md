# THE_MAPPS — стартовый проект

Нативное приложение на Kotlin + Compose Multiplatform. Карта подключена через MapLibre Compose. HTML и WebView не используются.

## Важно про Windows и iOS

Сборка iOS на Windows не входит в официальный стандартный путь JetBrains. Для этого проекта предусмотрен сторонний инструмент `xcross`, который заявляет сборку Compose Multiplatform iOS-приложений на Windows без локального Mac/Xcode.

`xcross` всё равно требует iOS SDK, извлечённый из архива Xcode (`.xip`). Для установки приложения на реальный iPhone потребуется действительная подпись. Сам факт создания IPA не означает, что неподписанный IPA можно установить и запустить.

## Что установлено в проекте

- Kotlin Multiplatform: 2.4.21
- Compose Multiplatform: 1.12.2
- MapLibre Compose: 0.20.0
- iOS target: arm64

Версии взяты из текущей документации Kotlin и MapLibre Compose на 17 ноября 2026 года. MapLibre Compose пока сохраняет статус API, который может меняться между версиями.

## Следующие шаги на Windows

1. Установить JDK 21 или новее.
2. Установить Android Studio или IntelliJ IDEA.
3. Установить Gradle 9.7.x либо открыть проект в IDE и позволить IDE настроить Gradle.
4. Установить xcross по официальной инструкции: https://xcross.sh/docs/installation/
5. Подготовить совместимый архив Xcode `.xip` и установить iOS SDK через `xcross sdk install <путь-к-Xcode.xip>`.
6. В корне проекта выполнить `xcross setup`, затем `xcross compose setup`.
7. Проверить окружение: `xcross compose doctor`.
8. Собирать IPA командой: `xcross compose build --ipa`.

## Примечание по карте

Пока подключён демонстрационный стиль MapLibre. Следующий этап — выбрать реальный стиль карты и источник тайлов, добавить атрибуцию OpenStreetMap, поиск, геолокацию и маршруты. Публичные тайловые серверы OSM не предназначены для неограниченной нагрузки; для постоянного использования нужно выбрать подходящий поставщик тайлов или собственный сервер.

## Документация

- xcross Compose: https://xcross.sh/docs/compose/
- xcross Quick Start: https://xcross.sh/docs/quick-start/
- MapLibre Compose: https://maplibre.org/maplibre-compose/getting-started/
- Kotlin Multiplatform: https://kotlinlang.org/docs/multiplatform/quickstart.html
